param([string]$GameDir = 'D:\steam\steamapps\common\GTFO')
$ErrorActionPreference = 'Stop'
& python (Join-Path $PSScriptRoot 'BuildRelease.py') --source $PSScriptRoot --game $GameDir
if ($LASTEXITCODE -ne 0) { throw 'CTE validation, build or packaging failed.' }
