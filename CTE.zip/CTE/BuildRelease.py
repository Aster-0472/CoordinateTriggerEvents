import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile

WORKSPACE = Path(r'D:\CodexWorkspaces\GTFO').resolve()
EXCLUDED = {'bin', 'obj', '.git', '__pycache__', 'test-artifacts', 'build-deps', 'results', 'generated', 'cache', 'temp'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--game', type=Path, default=Path(r'D:\steam\steamapps\common\GTFO'))
    parser.add_argument('--template', type=Path)
    options = parser.parse_args()
    source = options.source.resolve()
    if not source.is_relative_to(WORKSPACE) or WORKSPACE.drive.lower() != 'd:':
        raise RuntimeError('Source and generated outputs must physically remain under D:\\CodexWorkspaces\\GTFO')
    toa = (source / 'TOA_Heavy_Industries.csproj').is_file()
    name = 'TOA_Heavy_Industries' if toa else 'CoordinateTriggerEvents'
    version = '2.4.2' if toa else '1.8.1'
    project = source / (name + '.csproj') if toa else source / 'source' / (name + '.csproj')
    baseline = WORKSPACE / 'work/toa_2.4.1' if toa else WORKSPACE / 'CoordinateTriggerEvents_1.8.0_source_package'
    production = source if toa else source / 'source'
    previous = baseline if toa else baseline / 'source'
    changed = []
    for original in previous.rglob('*.cs'):
        relative = original.relative_to(previous)
        if any(part in EXCLUDED | {'validation'} for part in relative.parts):
            continue
        current = production / relative
        if current.read_bytes() != original.read_bytes():
            expected_plugin = 'Plugin.cs' if toa else 'Core/Plugin.cs'
            if relative.as_posix() != expected_plugin:
                raise RuntimeError('Unexpected production change: ' + str(relative))
            old_version = '2.4.1' if toa else '1.8.0'
            expected = original.read_text(encoding='utf-8-sig').replace('VERSION = "' + old_version + '"', 'VERSION = "' + version + '"').replace('[BepInDependency("dev.gtfomodding.gtfo-api", BepInDependency.DependencyFlags.HardDependency)]', '[BepInDependency("dev.gtfomodding.gtfo-api", "0.6.0")]')
            if current.read_text(encoding='utf-8-sig').rstrip('\r\n') != expected.rstrip('\r\n'):
                raise RuntimeError('Plugin.cs changes exceed version and API dependency migration')
            changed.append(relative.as_posix())
    for current in production.rglob('*.cs'):
        relative = current.relative_to(production)
        if not any(part in EXCLUDED | {'validation'} for part in relative.parts) and not (previous / relative).is_file():
            raise RuntimeError('Unexpected new production file: ' + str(relative))
    outputs = WORKSPACE / 'outputs'
    evidence = WORKSPACE / 'work/api_060_migration' / name
    evidence.mkdir(parents=True, exist_ok=True)
    destination = [outputs / (name + '_' + version + suffix) for suffix in ('_plugin_package.zip', '_source_package.zip')]
    if any(target.exists() for target in destination):
        raise RuntimeError('Release package already exists; refusing to overwrite')
    environment = os.environ.copy()
    for key, value in {'DOTNET_CLI_HOME': WORKSPACE / '.dotnet_home', 'NUGET_PACKAGES': WORKSPACE / '.nuget_packages', 'NUGET_HTTP_CACHE_PATH': evidence / 'nuget_cache', 'TEMP': evidence / 'temp', 'TMP': evidence / 'temp', 'PYTHONPYCACHEPREFIX': evidence / 'pycache'}.items():
        Path(value).mkdir(parents=True, exist_ok=True)
        environment[key] = str(value)
    environment['DOTNET_CLI_TELEMETRY_OPTOUT'] = '1'
    def run(label, command, expect_failure=False):
        result = subprocess.run([str(argument) for argument in command], cwd=WORKSPACE, env=environment, capture_output=True, encoding='utf-8', errors='replace')
        (evidence / (label + '.log')).write_text(result.stdout + result.stderr, encoding='utf-8')
        if (result.returncode == 0) == expect_failure:
            raise RuntimeError(label + ' failed; see ' + str(evidence / (label + '.log')))
        print(label + ': PASS', flush=True)
    if toa:
        run('assets', ['dotnet', 'run', '--project', source / 'validation/assets/Assets.Tests.csproj', '-c', 'Release', '-p:NuGetAudit=false', '--', options.game, evidence / 'asset_audit.json'])
        run('native_map_objects', ['dotnet', 'run', '--project', source / 'validation/native_map_objects/NativeMapObjects.Tests.csproj', '-c', 'Release', '-p:NuGetAudit=false'])
    else:
        run('hud', ['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', source / 'validation/run.ps1'])
    run('build', ['dotnet', 'build', project, '-c', 'Release', '-p:NuGetAudit=false', '-p:GameDir=' + str(options.game)])
    dll = project.parent / 'bin/Release/net6.0' / (name + '.dll')
    old_api = WORKSPACE / 'work/toa_2.4.1/build-deps/GTFO-API.dll'
    run('reject_old_api', ['dotnet', 'msbuild', project, '-t:ValidateGTFOApiVersion', '-p:GTFOApiPath=' + str(old_api)], expect_failure=True)
    if 'Expected GTFO-API 0.6.0.0' not in (evidence / 'reject_old_api.log').read_text(encoding='utf-8'):
        raise RuntimeError('Old API rejection did not reach the version guard')
    run('metadata', ['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', source / 'ValidateMetadata.ps1', '-GameDir', options.game, '-Dll', dll, '-Version', version])
    if toa:
        for label, project_name in [('network', 'network/Network.csproj'), ('revive', 'revive/Smoke.csproj')]:
            run(label, ['dotnet', 'run', '--project', source / 'validation' / project_name, '-c', 'Release', '-p:NuGetAudit=false', '--', dll])
        run('tts', ['python', source / 'validation/tts/test_tts.py'])
        run('interop', ['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', source / 'validation/tts/Test-Interop.ps1', '-GameDir', options.game, '-CecilPath', options.game / 'BepInEx/core/Mono.Cecil.dll'])
    entries = {}
    root_name = name + '_' + version + '_plugin_package/'
    unchanged = 0
    if toa:
        template = options.template or outputs / 'TOA_Heavy_Industries_2.4.1_plugin_package.zip'
        with zipfile.ZipFile(template) as archive:
            for entry in archive.infolist():
                if entry.is_dir():
                    continue
                relative = entry.filename.split('/', 1)[1]
                if relative in {'BUILD_INTEGRITY.json', 'README_2.4.1_CN.md'}:
                    continue
                data = archive.read(entry)
                if relative.endswith('/TOA_Heavy_Industries.dll'):
                    data = dll.read_bytes()
                elif relative.endswith('/TOA_Heavy_Industries.pdb'):
                    data = dll.with_suffix('.pdb').read_bytes()
                elif relative.endswith('/manifest.json'):
                    manifest = json.loads(data.decode('utf-8-sig'))
                    manifest['Version'] = version
                    manifest['MinimumGTFOAPI'] = '0.6.0'
                    data = json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8')
                else:
                    unchanged += 1
                if relative.startswith('BepInEx/Assets/AssetBundles/') and Path(relative).name in {'dummyvisuals-compressed', 'resource_station-compressed'}:
                    installed = options.game / 'BepInEx/Assets/AssetBundles/TOA_Assets' / Path(relative).name
                    if data != installed.read_bytes():
                        raise RuntimeError('Packaged resource differs from audited game resource: ' + relative)
                entries[relative] = data
        eventscan = source / 'release_assets/eventscan-compressed'
        installed = options.game / 'BepInEx/Assets/AssetBundles/TOA_Assets/eventscan-compressed'
        if eventscan.read_bytes() != installed.read_bytes():
            raise RuntimeError('EventScan package input differs from audited resource')
        entries['BepInEx/Assets/AssetBundles/eventscan-compressed'] = eventscan.read_bytes()
        entries['BepInEx/Assets/AssetBundles/eventscan-compressed.meta.json'] = eventscan.with_name(eventscan.name + '.meta.json').read_bytes()
    else:
        entries['BepInEx/plugins/' + name + '.dll'] = dll.read_bytes()
        entries['BepInEx/plugins/' + name + '.pdb'] = dll.with_suffix('.pdb').read_bytes()
        entries['manifest.json'] = (source / 'manifest.json').read_bytes()
    for document in ['README_' + version + '_CN.md', 'MIGRATION_REPORT_CN.md'] + (['RESOURCE_VALIDATION_CN.md'] if toa else []):
        entries[document] = (source / document).read_bytes()
    integrity = {'version': version, 'api': '0.6.0.0', 'production_changes': changed, 'unchanged_template_files': unchanged, 'files': {key: digest(value) for key, value in entries.items()}}
    entries['BUILD_INTEGRITY.json'] = json.dumps(integrity, ensure_ascii=False, indent=2).encode('utf-8')
    with zipfile.ZipFile(destination[0], 'x', zipfile.ZIP_DEFLATED) as archive:
        for relative, data in entries.items():
            archive.writestr(root_name + relative, data)
    with zipfile.ZipFile(destination[0]) as archive:
        assert archive.testzip() is None
        for relative, data in entries.items():
            assert archive.read(root_name + relative) == data
    with zipfile.ZipFile(destination[1], 'x', zipfile.ZIP_DEFLATED) as archive:
        for current in sorted(source.rglob('*')):
            relative = current.relative_to(source)
            if current.is_file() and not any(part in EXCLUDED for part in relative.parts) and current.suffix != '.zip':
                archive.write(current, name + '_' + version + '_source_package/' + relative.as_posix())
    with zipfile.ZipFile(destination[1]) as archive:
        assert archive.testzip() is None
        for entry in archive.infolist():
            assert archive.read(entry) == (source / entry.filename.split('/', 1)[1]).read_bytes()
    report = {**integrity, 'packages': {str(target): digest(target.read_bytes()) for target in destination}}
    (outputs / (name + '_' + version + '_package_validation.json')).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report['packages'], indent=2))


if __name__ == '__main__':
    main()
