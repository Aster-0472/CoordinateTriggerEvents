param([string]$GameDir = 'D:\STEAM\steamapps\common\GTFO')
$ErrorActionPreference = 'Stop'
$package = Split-Path -Parent $PSScriptRoot
if (-not $package.StartsWith('D:\CodexWorkspaces\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Use a D-drive workspace.' }
$env:DOTNET_CLI_HOME = 'D:\CodexWorkspaces\GTFO\.dotnet_home'
$env:NUGET_PACKAGES = 'D:\CodexWorkspaces\GTFO\.nuget_packages'
$env:NUGET_HTTP_CACHE_PATH = Join-Path $package 'validation\cache'
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
$env:DOTNET_SKIP_FIRST_TIME_EXPERIENCE = '1'
$env:TEMP = Join-Path $package 'validation\temp'
$env:TMP = $env:TEMP
New-Item -ItemType Directory -Force -Path $env:TEMP | Out-Null
$control = Get-Content (Join-Path $package 'source\WardenEvents\TriggerControlEvent.cs') -Raw
$match = [regex]::Match($control, '(?s)    private static int ApplyTriggerControlState\(string targetID, string category, bool enabled\).*?return changed;\s*}')
if (-not $match.Success) { throw 'Control method extraction failed.' }
$generated = Join-Path $PSScriptRoot 'generated'
New-Item -ItemType Directory -Force -Path $generated | Out-Null
[IO.File]::WriteAllText((Join-Path $generated 'ControlMethod.cs'), "using System;`nnamespace CoordinateTriggerEvents;`ninternal static partial class Runtime {`n" + $match.Value + "`n}")
dotnet run --project (Join-Path $PSScriptRoot 'HudState.Tests.csproj') -c Release --no-launch-profile -p:NuGetAudit=false
if ($LASTEXITCODE -ne 0) { throw 'HUD state tests failed.' }
