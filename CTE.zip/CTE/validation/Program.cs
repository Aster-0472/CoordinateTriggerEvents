using System;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using CoordinateTriggerEvents;
using GTFO.API;

internal static class Program
{
    private static int Checks;
    private static TestPeer Host => TestWorld.Peers[1];
    private static TestPeer Client => TestWorld.Peers[2];
    private static void Check(bool condition, string description)
    {
        if (!condition) throw new Exception("FAIL: " + description);
        Checks++;
        Console.WriteLine("PASS: " + description);
    }
    private static void Start(ulong peer)
    {
        TestWorld.Switch(peer);
        HudInteractStateSync.StartExpedition();
    }
    private static void SetHost(bool enabled)
    {
        TestWorld.Switch(1);
        Runtime.Control("hud-test", "HudInteract", enabled);
    }
    private static void Main()
    {
        TestWorld.Peers.Add(1, new TestPeer(1, true));
        TestWorld.Peers.Add(2, new TestPeer(2, false));
        TestWorld.Switch(1);
        HudInteractStateSync.Setup();
        Start(1);
        Start(2);
        NetworkAPI.Pump();
        Check(Client.Hud.Enabled, "initial snapshot resolves initially disabled client HUD");
        Check(Marshal.SizeOf<HudInteractStatePacket>() == 128, "state packet is bounded to 128 bytes");
        SetHost(false);
        NetworkAPI.Pump();
        Check(!Host.Hud.Enabled && !Client.Hud.Enabled, "host disable reaches client");
        SetHost(true);
        NetworkAPI.Pump();
        Check(Host.Hud.Enabled && Client.Hud.Enabled, "host-only re-enable reaches disabled client");
        TestWorld.Switch(2);
        int changed = Runtime.Control("hud-test", "HudInteract", false);
        Check(changed == 0 && Client.Hud.Enabled, "late client-local control cannot undo authoritative state");
        int messages = NetworkAPI.History.Count;
        for (int iteration = 0; iteration < 10000; iteration++) SetHost(true);
        Check(NetworkAPI.History.Count == messages, "10000 unchanged control events send zero packets");
        SetHost(false);
        SetHost(true);
        Envelope[] reordered = NetworkAPI.Pending.ToArray();
        NetworkAPI.Pending.Clear();
        NetworkAPI.Deliver(reordered[1]);
        int dirty = Client.DirtyCount;
        NetworkAPI.Deliver(reordered[0]);
        NetworkAPI.Deliver(reordered[1]);
        Check(Client.Hud.Enabled && Client.DirtyCount == dirty, "stale and duplicate revisions cannot roll state back or dirty cache");
        HudInteractStatePacket invalid = reordered[1].Packet;
        invalid.Enabled = 0;
        invalid.Revision += 100;
        NetworkAPI.Deliver(new Envelope(999, 2, invalid));
        Check(Client.Hud.Enabled, "non-master state is rejected");
        invalid.LayoutId = 99;
        NetworkAPI.Deliver(new Envelope(1, 2, invalid));
        Check(Client.Hud.Enabled, "other-layout state is rejected");
        invalid = reordered[1].Packet;
        invalid.Enabled = 0;
        invalid.Revision += 100;
        invalid.Epoch++;
        NetworkAPI.Deliver(new Envelope(1, 2, invalid));
        Check(Client.Hud.Enabled, "unknown-session delta is rejected");
        invalid.Epoch--;
        invalid.RequestId = ulong.MaxValue;
        NetworkAPI.Deliver(new Envelope(1, 2, invalid));
        Check(Client.Hud.Enabled, "snapshot with wrong handshake nonce is rejected");
        invalid.RequestId = 0;
        invalid.TriggerIdByteCount = 97;
        NetworkAPI.Deliver(new Envelope(1, 2, invalid));
        Check(Client.Hud.Enabled, "oversized trigger ID is rejected");
        TestWorld.Switch(2);
        Client.Configs[0].HudInteractTriggers.Clear();
        Client.Configs[0].HudInteractTriggers.Add(new HudInteractTriggerRule { Enabled = false });
        HudInteractStateSync.ConfigurationChanged();
        Check(Client.Hud.Enabled, "client config reload reapplies known host state without waiting for tick");
        NetworkAPI.Pump();
        TestWorld.Switch(2);
        LevelAPI.Cleanup();
        Client.Hud.Enabled = false;
        Start(2);
        NetworkAPI.Pump();
        Check(Client.Hud.Enabled, "late client restart requests current host snapshot");
        TestWorld.Switch(2);
        messages = NetworkAPI.History.Count;
        typeof(HudInteractStateRecallPatch).GetMethod("Postfix", BindingFlags.NonPublic | BindingFlags.Static)!.Invoke(null, null);
        Check(NetworkAPI.History.Count == messages + 1 && NetworkAPI.History[^1].Target == 1, "recall issues one targeted snapshot request");
        NetworkAPI.Pump();
        TestWorld.Switch(2);
        EventAPI.CheckpointReloaded();
        NetworkAPI.Pump();
        Check(Client.Hud.Enabled, "checkpoint event refreshes current HUD authority");
        TestWorld.Switch(1);
        Host.Hud.Enabled = false;
        HudInteractStateSync.ConfigurationChanged();
        NetworkAPI.Pump();
        Check(!Client.Hud.Enabled, "host config reload publishes authoritative HUD defaults");
        TestWorld.Switch(1);
        messages = NetworkAPI.History.Count;
        Check(Runtime.Control("hud-test", "Position", false) == 1, "Position control retains original changed count");
        Check(Runtime.Control("hud-test", "Scan", false) == 1, "Scan control retains original changed count");
        Check(Runtime.Control("hud-test", "Interact", false) == 1, "Interact control retains original changed count");
        Check(NetworkAPI.History.Count == messages, "non-HUD control sends no new state packets");
        Check(Client.Configs[0].PositionTriggers[0].Enabled && Client.Configs[0].ScanTriggers[0].Enabled && Client.Configs[0].InteractTriggers[0].Enabled, "non-HUD client semantics remain unchanged");
        ConfigDocument otherLayout = new() { LayoutId = 99 };
        otherLayout.HudInteractTriggers.Add(new HudInteractTriggerRule { ID = "other-layout" });
        Host.Configs.Add(otherLayout);
        TestWorld.Switch(1);
        HudInteractStateSync.ConfigurationChanged();
        NetworkAPI.Pump();
        Check(!NetworkAPI.History.Any(entry => entry.Packet.TriggerIdByteCount > 0 && System.Text.Encoding.UTF8.GetString(entry.Packet.TriggerIdPayload, 0, entry.Packet.TriggerIdByteCount) == "other-layout"), "snapshot excludes rules for other layouts");
        SetHost(true);
        Envelope oldSession = NetworkAPI.Pending[0];
        NetworkAPI.Pending.Clear();
        TestWorld.Switch(1);
        LevelAPI.BuildStart();
        Start(1);
        TestWorld.Switch(2);
        LevelAPI.BuildStart();
        Start(2);
        NetworkAPI.Pump();
        invalid = oldSession.Packet;
        invalid.Enabled = 0;
        invalid.Revision = ulong.MaxValue;
        NetworkAPI.Deliver(new Envelope(1, 2, invalid));
        Check(Client.Hud.Enabled, "prior expedition session cannot overwrite rebuilt level state");
        TestWorld.Switch(2);
        LevelAPI.Cleanup();
        Client.Hud.Enabled = false;
        NetworkAPI.Deliver(oldSession);
        Check(!Client.Hud.Enabled, "cleanup stops state application");
        TestWorld.Switch(1);
        Host.Configs[0].HudInteractTriggers.Clear();
        Host.Configs.Remove(otherLayout);
        messages = NetworkAPI.History.Count;
        Start(1);
        Check(NetworkAPI.History.Count == messages, "no HUD configuration causes zero startup traffic");
        Check(Host.Errors.Count == 0 && Client.Errors.Count == 0, "no sync exceptions were swallowed during tests");
        Console.WriteLine($"HUD STATE CHECKS PASSED: {Checks}");
        Console.WriteLine("LIMIT: real production sync/control methods with simulated transport and lifecycle; no in-game validation.");
    }
}
