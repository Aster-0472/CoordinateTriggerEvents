param([string]$Baseline = (Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) 'CoordinateTriggerEvents_1.7.9_source_package'))
$ErrorActionPreference = 'Stop'
$package = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path -LiteralPath $Baseline)) { throw 'Baseline source package is required for scope verification.' }
$allowed = @('Core\Plugin.cs','Core\Runtime.cs','HudInteractTriggers\HudInteractTriggerManager.cs','WardenEvents\TriggerControlEvent.cs','CoordinateTriggerEvents.csproj')
$newFiles = @('HudInteractTriggers\HudInteractStateSync.cs','HudInteractTriggers\HudInteractStatePacket.cs')
$source = Join-Path $package 'source'
$baselineSource = Join-Path $Baseline 'source'
$compared = 0
foreach ($file in Get-ChildItem -LiteralPath $baselineSource -Recurse -File) {
    $relative = $file.FullName.Substring($baselineSource.Length + 1)
    if ($relative -match '^(bin|obj)\\') { continue }
    $current = Join-Path $source $relative
    if (-not (Test-Path -LiteralPath $current)) { throw "Baseline file missing: $relative" }
    if ($allowed -notcontains $relative -and (Get-FileHash $current).Hash -ne (Get-FileHash $file.FullName).Hash) { throw "Unapproved file changed: $relative" }
    $compared++
}
foreach ($file in Get-ChildItem -LiteralPath $source -Recurse -File) {
    $relative = $file.FullName.Substring($source.Length + 1)
    if ($relative -match '^(bin|obj)\\') { continue }
    if (-not (Test-Path -LiteralPath (Join-Path $baselineSource $relative)) -and $newFiles -notcontains $relative) { throw "Unexpected new runtime source: $relative" }
}
function Read-ByteText([string]$Path) { return [Text.Encoding]::GetEncoding(28591).GetString([IO.File]::ReadAllBytes($Path)).Replace("`r`n", "`n").TrimEnd([char[]]"`r`n") }
$runtime = Read-ByteText (Join-Path $source 'Core\Runtime.cs')
foreach ($line in @('        HudInteractStateSync.ConfigurationChanged();','        HudInteractStateSync.Setup();','        HudInteractStateSync.StartExpedition();')) { $runtime = $runtime.Replace($line + "`n", '') }
if ($runtime -cne (Read-ByteText (Join-Path $baselineSource 'Core\Runtime.cs'))) { throw 'Runtime changed outside three approved HUD hooks.' }
$control = Read-ByteText (Join-Path $source 'WardenEvents\TriggerControlEvent.cs')
$oldControl = Read-ByteText (Join-Path $baselineSource 'WardenEvents\TriggerControlEvent.cs')
$hudStart = $oldControl.IndexOf('            if ((matchAnyCategory || normalizedCategory == "hudinteract"')
if ($hudStart -lt 0) { throw 'HUD control branch not found.' }
$expected = $oldControl.Substring(0,$hudStart) + $oldControl.Substring($hudStart).Replace('IDMatches(trigger.ID) && trigger.Enabled != enabled','IDMatches(trigger.ID) && HudInteractStateSync.SetEnabled(trigger, enabled)').Replace('                        trigger.Enabled = enabled;' + "`n",'')
if ($control -cne $expected) { throw 'Control changed outside HUD branch.' }
$hud = Read-ByteText (Join-Path $source 'HudInteractTriggers\HudInteractTriggerManager.cs')
$oldHud = Read-ByteText (Join-Path $baselineSource 'HudInteractTriggers\HudInteractTriggerManager.cs')
$expected = $oldHud.Replace('            ExecuteConfirmedStage(confirm);' + "`n" + '            Runtime.BroadcastHudInteractConfirm(confirm);','            Runtime.BroadcastHudInteractConfirm(confirm);' + "`n" + '            ExecuteConfirmedStage(confirm);')
if ($hud -cne $expected) { throw 'HUD manager changed outside confirm/state send ordering.' }
$plugin = Read-ByteText (Join-Path $source 'Core\Plugin.cs')
if ($plugin -cne (Read-ByteText (Join-Path $baselineSource 'Core\Plugin.cs')).Replace('VERSION = "1.7.6"','VERSION = "1.8.0"')) { throw 'Plugin changed outside version metadata.' }
$sync = Get-Content (Join-Path $source 'HudInteractTriggers\HudInteractStateSync.cs') -Raw
if ($sync -match '\b(Update|Tick|Timer|Thread|Task)\b|realtimeSinceStartup|OnUpdate|Coroutine') { throw 'HUD state sync must remain event-driven.' }
Write-Output "PASS: $compared baseline files checked; only approved HUD hooks, ordering and release version differ."
Write-Output 'PASS: Position/Scan/Interact/Models/Debug files are byte-identical to baseline.'
Write-Output 'PASS: no new update/timer/thread/coroutine or periodic polling in HUD state sync.'
