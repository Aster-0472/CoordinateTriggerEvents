using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using CoordinateTriggerEvents;

namespace HarmonyLib
{
    [AttributeUsage(AttributeTargets.Class)]
    internal sealed class HarmonyPatch : Attribute { internal HarmonyPatch(Type type, string method) { } }
}
namespace SNetwork
{
    internal enum SNet_ChannelType { GameOrderCritical }
    internal sealed class SNet_Player { public ulong Lookup; }
    internal sealed class SNet_GlobalManager { public void OnRecallComplete() { } }
    internal static class SNet
    {
        internal static bool IsMaster => TestWorld.Current!.Id == 1;
        internal static bool HasMaster => true;
        internal static SNet_Player Master = new() { Lookup = 1 };
        internal static bool TryGetPlayer(ulong sender, out SNet_Player player)
        {
            player = new SNet_Player { Lookup = sender };
            return TestWorld.Peers.ContainsKey(sender);
        }
    }
}
namespace GTFO.API
{
    using SNetwork;
    internal static class LevelAPI
    {
        internal static event Action? OnBuildStart;
        internal static event Action? OnLevelCleanup;
        internal static void BuildStart() => OnBuildStart?.Invoke();
        internal static void Cleanup() => OnLevelCleanup?.Invoke();
    }
    internal static class EventAPI
    {
        internal static event Action? OnCheckpointReloaded;
        internal static void CheckpointReloaded() => OnCheckpointReloaded?.Invoke();
    }
    internal sealed record Envelope(ulong Sender, ulong Target, HudInteractStatePacket Packet);
    internal static class NetworkAPI
    {
        internal static Action<ulong, HudInteractStatePacket>? Handler;
        internal static readonly List<Envelope> Pending = new();
        internal static readonly List<Envelope> History = new();
        internal static void RegisterEvent<T>(string name, Action<ulong, T> handler) where T : struct
        {
            Handler = (sender, packet) => handler(sender, (T)(object)packet);
        }
        internal static void InvokeEvent<T>(string name, T packet, SNet_ChannelType channel) where T : struct
        {
            foreach (ulong peer in TestWorld.Peers.Keys)
            {
                if (peer != TestWorld.Current!.Id) Enqueue(peer, (HudInteractStatePacket)(object)packet);
            }
        }
        internal static void InvokeEvent<T>(string name, T packet, SNet_Player target, SNet_ChannelType channel) where T : struct
        {
            Enqueue(target.Lookup, (HudInteractStatePacket)(object)packet);
        }
        private static void Enqueue(ulong target, HudInteractStatePacket packet)
        {
            Envelope envelope = new(TestWorld.Current!.Id, target, packet);
            Pending.Add(envelope);
            History.Add(envelope);
        }
        internal static void Deliver(Envelope envelope)
        {
            TestWorld.Switch(envelope.Target);
            Handler!(envelope.Sender, envelope.Packet);
        }
        internal static void Pump()
        {
            int processed = 0;
            while (Pending.Count > 0)
            {
                if (++processed > 1000) throw new Exception("Unbounded network exchange.");
                Envelope envelope = Pending[0];
                Pending.RemoveAt(0);
                Deliver(envelope);
            }
        }
    }
}
namespace CoordinateTriggerEvents
{
    internal static class PluginInfo { internal const string GUID = "com.gtfo.coordinatetriggerevents"; }
    internal class TriggerRule { public string ID = "hud-test"; public bool Enabled = true; }
    internal sealed class HudInteractTriggerRule : TriggerRule { }
    internal sealed class PositionTriggerRule : TriggerRule { }
    internal sealed class ScanTriggerRule : TriggerRule { }
    internal sealed class InteractTriggerRule : TriggerRule { }
    internal sealed class ConfigDocument
    {
        public bool Enabled = true;
        public uint LayoutId = 10;
        public List<HudInteractTriggerRule> HudInteractTriggers = new();
        public List<PositionTriggerRule> PositionTriggers = new() { new() };
        public List<ScanTriggerRule> ScanTriggers = new() { new() };
        public List<InteractTriggerRule> InteractTriggers = new() { new() };
    }
    internal static class ConfigManager { internal static List<ConfigDocument> Configs => TestWorld.Current!.Configs; }
    internal static partial class Runtime
    {
        internal const int MaxHudInteractTriggerIdBytes = 96;
        private static uint GetCurrentLevelLayoutId() => TestWorld.Current!.LayoutId;
        private static string TryGetLevelLayoutName(uint layoutId) => "test-layout";
        private static bool MatchesCurrentLevel(ConfigDocument config, uint layoutId, string name, out string reason)
        {
            reason = string.Empty;
            return config.LayoutId == layoutId;
        }
        internal static void MarkActiveTriggerCacheDirty() => TestWorld.Current!.DirtyCount++;
        internal static void LogThrottled(string message) => TestWorld.Current!.Errors.Add(message);
        private static string NormalizeTargetType(string category) => category.ToLowerInvariant();
        internal static int Control(string id, string category, bool enabled) => ApplyTriggerControlState(id, category, enabled);
    }
}
internal sealed class TestPeer
{
    internal readonly ulong Id;
    internal readonly List<ConfigDocument> Configs = new();
    internal readonly List<string> Errors = new();
    internal readonly Dictionary<FieldInfo, object?> Saved = new();
    internal uint LayoutId = 10;
    internal int DirtyCount;
    internal TestPeer(ulong id, bool enabled)
    {
        Id = id;
        ConfigDocument config = new();
        config.HudInteractTriggers.Add(new HudInteractTriggerRule { Enabled = enabled });
        Configs.Add(config);
    }
    internal HudInteractTriggerRule Hud => Configs[0].HudInteractTriggers[0];
}
internal static class TestWorld
{
    internal static TestPeer? Current;
    internal static readonly Dictionary<ulong, TestPeer> Peers = new();
    private static readonly FieldInfo[] Fields = typeof(HudInteractStateSync).GetFields(BindingFlags.NonPublic | BindingFlags.Static);
    internal static void Switch(ulong id)
    {
        if (Current?.Id == id) return;
        if (Current != null)
        {
            foreach (FieldInfo field in Fields)
            {
                if (field.IsLiteral || field.Name == "Registered") continue;
                object? value = field.GetValue(null);
                if (value is IDictionary dictionary)
                {
                    List<DictionaryEntry> entries = new();
                    foreach (DictionaryEntry entry in dictionary) entries.Add(entry);
                    value = entries;
                }
                Current.Saved[field] = value;
            }
        }
        Current = Peers[id];
        if (Current.Saved.Count == 0)
        {
            HudInteractStateSync.Reset();
            return;
        }
        foreach (KeyValuePair<FieldInfo, object?> saved in Current.Saved)
        {
            if (saved.Key.GetValue(null) is IDictionary dictionary)
            {
                dictionary.Clear();
                foreach (DictionaryEntry entry in (List<DictionaryEntry>)saved.Value!) dictionary.Add(entry.Key, entry.Value);
            }
            else saved.Key.SetValue(null, saved.Value);
        }
    }
}
