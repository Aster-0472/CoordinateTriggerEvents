param([string]$GameDir, [string]$Dll, [string]$Version)
$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $GameDir 'BepInEx/core/Mono.Cecil.dll')
$resolver = [Mono.Cecil.DefaultAssemblyResolver]::new()
$resolver.AddSearchDirectory((Join-Path $GameDir 'BepInEx/core'))
$resolver.AddSearchDirectory((Join-Path $GameDir 'BepInEx/interop'))
$api = Join-Path $GameDir 'BepInEx/plugins/GTFO-API.dll'
if (-not (Test-Path $api)) { $api = Join-Path $GameDir 'BepInEx/plugins/GTFO_API/GTFO-API.dll' }
$resolver.AddSearchDirectory((Split-Path $api))
$parameters = [Mono.Cecil.ReaderParameters]::new()
$parameters.AssemblyResolver = $resolver
$assembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($Dll, $parameters)
try {
    if ($assembly.Name.Version.ToString() -ne "$Version.0") { throw 'Assembly version mismatch' }
    $reference = @($assembly.MainModule.AssemblyReferences | Where-Object Name -eq 'GTFO-API')
    if ($reference.Count -ne 1 -or $reference[0].Version.ToString() -ne '0.6.0.0') { throw 'API assembly reference mismatch' }
    if (@($assembly.MainModule.AssemblyReferences | Where-Object Name -match 'AmorLib').Count) { throw 'Unexpected AmorLib dependency' }
    $attributes = @($assembly.MainModule.Types.CustomAttributes)
    $plugin = @($attributes | Where-Object { $_.AttributeType.FullName -eq 'BepInEx.BepInPlugin' })
    if ($plugin.Count -ne 1 -or $plugin[0].ConstructorArguments[2].Value -ne $Version) { throw 'Plugin version mismatch' }
    $dependency = @($attributes | Where-Object { $_.AttributeType.FullName -eq 'BepInEx.BepInDependency' -and $_.ConstructorArguments[0].Value -eq 'dev.gtfomodding.gtfo-api' })
    if ($dependency.Count -ne 1 -or $dependency[0].ConstructorArguments[1].Value -ne '0.6.0') { throw 'Minimum API dependency mismatch' }
    $count = 0
    foreach ($member in $assembly.MainModule.GetMemberReferences()) {
        if ($member.DeclaringType.GetElementType().Scope.Name -ne 'GTFO-API') { continue }
        if ($null -eq $member.Resolve()) { throw "Unresolved API member: $member" }
        $count++
    }
    Write-Output "PASS: $Version; compiled GTFO-API=0.6.0.0; minimum=0.6.0; $count API member references resolved; no AmorLib."
} finally { $assembly.Dispose(); $resolver.Dispose() }
